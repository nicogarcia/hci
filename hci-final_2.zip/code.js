var map;
var sliderBox;

function Barrio() {
	this.polygon = "";
	this.name = "";
	this.data = [ [ 'Luz', 8, 10 ], [ 'Gas', 5, 9 ], [ 'Agua', 5, 9 ],
			[ '911', 5, 9 ], [ 'Accidentes', 5, 9 ], [ 'Robos', 5, 9 ],
			[ 'Homicidios', 10, 0 ], ];
};

var names = [ "Centro", "Tiro Federal", "Universitario" ];
var myCoordinates = [// centro
		[ new google.maps.LatLng(-38.716366, -62.275073),
				new google.maps.LatLng(-38.710472, -62.267348),
				new google.maps.LatLng(-38.716433, -62.259795),
				new google.maps.LatLng(-38.721321, -62.268121) ],

		// tiro
		[ new google.maps.LatLng(-38.719245, -62.253186),
				new google.maps.LatLng(-38.715629, -62.241513),
				new google.maps.LatLng(-38.718910, -62.236406),
				new google.maps.LatLng(-38.723397, -62.242286),
				new google.maps.LatLng(-38.728151, -62.252843),
				new google.maps.LatLng(-38.719111, -62.251641) ],
		// universitario
		[ new google.maps.LatLng(-38.704879, -62.279751),
				new google.maps.LatLng(-38.709501, -62.273313),
				new google.maps.LatLng(-38.705817, -62.267134),
				new google.maps.LatLng(-38.699253, -62.273142) ],

];

var barrios = [];
var infowindow;

// Funcion inicial
function init() {
	init_barrios();
	init_map();
	init_drawing();
}

// Inicializar los barrios: poner nombre, crear poligono
function init_barrios() {
	for ( var i = 0; i < names.length; i++) {
		var b = new Barrio();
		b.name = names[i];

		var polyOptions = {
			path : myCoordinates[i],
			strokeColor : "#0000FF",
			strokeOpacity : 0.8,
			strokeWeight : 1,
			fillColor : "#0000AA",
			fillOpacity : 0.6
		};

		b.polygon = new google.maps.Polygon(polyOptions);
		barrios.push(b);
	}
}

// Inicializar mapa
function init_map() {

	/** Initialize map things */
	var latlng = new google.maps.LatLng(-38.712615, -62.265717);
	var myOptions = {
		zoom : 12,
		center : latlng,
		mapTypeId : google.maps.MapTypeId.ROADMAP,
		disableDefaultUI : true,
		zoomControl : true
	};
	map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);

	infowindow = new google.maps.InfoWindow();

	var sliderBoxDiv = document.createElement('div');
	sliderBox = new SliderBox(sliderBoxDiv, map);

	sliderBoxDiv.index = -500;
	map.controls[google.maps.ControlPosition.TOP_RIGHT].push(sliderBoxDiv);

	/** *************************************** */

	// Add polygons to map
	for ( var i = 0; i < barrios.length; i++) {
		var b = barrios[i];
		b.polygon.setMap(map);
		b.polygon.set('barrio', b);

		// Add click event listener for each polygon
		google.maps.event.addListener(b.polygon, 'click', function(event, b) {
			var barrio = this.get('barrio');
			infowindow.setContent('<center><h1>' + barrio.name
					+ '</h1></center>');
			infowindow.setPosition(event.latLng);
			infowindow.open(map);

			// Fill table
			fillTable(barrio);
		});

	}

}

// Crear panel deslizante derecho
function SliderBox(controlDiv, map) {

	var control = this;
	control.isOpen = false;

	// set panel height to 100%
	controlDiv.style.height = '100%';

	// Put sliderbox (panel) inside the map
	var box = document.getElementById('sliderbox');
	controlDiv.appendChild(box);

	$('#toggleBtn').live('click', function() {
		var signo;
		var arrow;
		if (control.isOpen) {
			signo = "-";
			arrow = "left";
		} else {
			signo = "+";
			arrow = "right";
		}
		$("#sliderbox").animate({
			"marginRight" : signo + "=470px"
		}, {
			duration : 500,
			step : function() {
				google.maps.event.trigger(map, 'resize');
			}
		});
		control.isOpen = !control.isOpen;
		toggleBtn.style.backgroundImage = "url('arrow-" + arrow + ".png')";

		;
	});
}

// Llenar la tabla y abrir panel
function fillTable(barrio) {
	var table = document.getElementById('data_table');
	var col = 0;
	for ( var row = 0; row < barrio.data.length; row++) {
		table.rows[row + 1].cells[col].innerHTML = barrio.data[row][0];
		table.rows[row + 1].cells[col + 1].innerHTML = Math
				.floor(Math.random() * 50 + 20);
		table.rows[row + 1].cells[col + 2].innerHTML = '';
	}
	if (!sliderBox.isOpen)
		$('#toggleBtn').trigger('click');
}
